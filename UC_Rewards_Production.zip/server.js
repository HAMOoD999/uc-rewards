const express=require("express");
const helmet=require("helmet");
const Database=require("better-sqlite3");
const crypto=require("crypto");
const app=express(),db=new Database("rewards.db");
app.use(helmet({contentSecurityPolicy:false})); app.use(express.json({limit:"20kb"})); app.use(express.static("public"));
db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,balance INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,name TEXT NOT NULL,points INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS completions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,task_id TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_id,task_id));
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,amount INTEGER NOT NULL,reason TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS redemptions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,points INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL);`);
if(!db.prepare("SELECT COUNT(*) n FROM tasks").get().n){let q=db.prepare("INSERT INTO tasks VALUES(?,?,?,1)");q.run("daily","المهمة اليومية",500);q.run("bonus","المهمة الإضافية",1000)}
const now=()=>new Date().toISOString(),get=u=>db.prepare("SELECT * FROM users WHERE id=?").get(u);
function auth(req,res,next){let id=String(req.headers["x-user-id"]||"");if(!id||!get(id))return res.status(401).json({error:"سجل الدخول أولاً"});req.uid=id;next()}
app.post("/api/register",(req,res)=>{let n=String(req.body.username||"").trim().slice(0,40);if(n.length<2)return res.status(400).json({error:"اسم المستخدم غير صالح"});let u=db.prepare("SELECT * FROM users WHERE username=?").get(n);if(!u){let id=crypto.randomUUID();db.prepare("INSERT INTO users VALUES(?,?,0,?)").run(id,n,now());u=get(id)}res.json({userId:u.id,username:u.username,balance:u.balance})});
app.get("/api/me",auth,(req,res)=>{let u=get(req.uid);res.json({username:u.username,balance:u.balance})});
app.get("/api/tasks",(req,res)=>res.json(db.prepare("SELECT id,name,points FROM tasks WHERE active=1").all()));
app.post("/api/complete-task",auth,(req,res)=>{let t=db.prepare("SELECT * FROM tasks WHERE id=? AND active=1").get(String(req.body.taskId||""));if(!t)return res.status(404).json({error:"المهمة غير موجودة"});try{db.transaction(()=>{db.prepare("INSERT INTO completions(user_id,task_id,created_at) VALUES(?,?,?)").run(req.uid,t.id,now());db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(t.points,req.uid);db.prepare("INSERT INTO ledger(user_id,amount,reason,created_at) VALUES(?,?,?,?)").run(req.uid,t.points,"إكمال "+t.name,now())})();res.json({success:true,added:t.points,balance:get(req.uid).balance})}catch(e){if(String(e).includes("UNIQUE"))return res.status(409).json({error:"تم إكمال هذه المهمة مسبقًا"});res.status(500).json({error:"تعذر تسجيل المهمة"})}});
app.post("/api/redeem",auth,(req,res)=>{let u=get(req.uid),p=10000;if(u.balance<p)return res.status(400).json({error:"الرصيد غير كافٍ"});let id=crypto.randomUUID();db.transaction(()=>{db.prepare("UPDATE users SET balance=balance-? WHERE id=?").run(p,req.uid);db.prepare("INSERT INTO ledger(user_id,amount,reason,created_at) VALUES(?,?,?,?)").run(req.uid,-p,"طلب استبدال",now());db.prepare("INSERT INTO redemptions VALUES(?,?,?,?,?)").run(id,req.uid,p,"pending",now())})();res.json({success:true,requestId:id,balance:get(req.uid).balance})});
app.get("/api/history",auth,(req,res)=>res.json(db.prepare("SELECT amount,reason,created_at FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 100").all(req.uid)));
app.listen(process.env.PORT||3000,()=>console.log("UC Rewards server running"));